#!/usr/bin/env python3

import rospy
import random
import numpy as np
import sensor_msgs.point_cloud2 as pc2
from sensor_msgs.msg import PointCloud2, PointField
from sklearn.cluster import DBSCAN
from geometry_msgs.msg import Point, Vector3
from rubber_cone_mission.msg import BoundingBox, BoundingBoxArray  # Custom messages
from rubber_cone_mission.msg import CentroidWithLabel, CentroidWithLabelArray  # Custom messages for centroids
from visualization_msgs.msg import Marker, MarkerArray

class Plane:
    def __init__(self):
        self.inliers = []
        self.equation = []

    def fit(self, pts, thresh=0.05, maxIteration=500):
        n_points = pts.shape[0]
        if n_points < 3:
            return None, []

        best_eq = None
        best_inliers = []

        for _ in range(maxIteration):
            id_samples = random.sample(range(n_points), 3)
            pt_samples = pts[id_samples]

            vecA = pt_samples[1] - pt_samples[0]
            vecB = pt_samples[2] - pt_samples[0]
            vecC = np.cross(vecA, vecB)
            norm_vecC = np.linalg.norm(vecC)
            if norm_vecC == 0:
                continue
            vecC = vecC / norm_vecC

            k = -np.dot(vecC, pt_samples[0])
            plane_eq = np.append(vecC, k)

            distances = np.abs(np.dot(pts, vecC) + k)
            inliers = np.where(distances <= thresh)[0]

            if len(inliers) > len(best_inliers):
                best_eq = plane_eq
                best_inliers = inliers

        self.inliers = best_inliers
        self.equation = best_eq
        return best_eq, best_inliers

class LidarProcessor:
    def __init__(self):
        rospy.init_node('lidar_processor', anonymous=True)
        
        # Subscribers
        self.point_cloud_sub = rospy.Subscriber("/velodyne_points", PointCloud2, self.point_cloud_callback, queue_size=1)
        
        # Publishers
        self.centroid_pub = rospy.Publisher("/centroid_info", CentroidWithLabelArray, queue_size=1)
        self.processed_points_pub = rospy.Publisher("/processed_points", PointCloud2, queue_size=1)
        self.clustered_points_pub = rospy.Publisher("/clustered_points", PointCloud2, queue_size=1)
        self.centroid_markers_pub = rospy.Publisher("/centroid_markers", MarkerArray, queue_size=1)
        self.text_markers_pub = rospy.Publisher("/centroid_text_markers", MarkerArray, queue_size=1)  # 텍스트 마커 퍼블리셔 추가
        
        # Parameters
        self.voxel_size = rospy.get_param("~voxel_size", 0.01)  # Voxel grid size for downsampling
        self.crop_x = rospy.get_param("~crop_x", (0, 6))
        self.crop_y = rospy.get_param("~crop_y", (-3, 3))
        self.crop_z = rospy.get_param("~crop_z", (-0.5, 1))
        self.plane_thresh = rospy.get_param("~plane_thresh", 0.02)  # RANSAC threshold for plane fitting
        self.plane_max_iter = rospy.get_param("~plane_max_iter", 100)  # RANSAC max iterations
        self.dbscan_eps = rospy.get_param("~dbscan_eps", 0.3)  # DBSCAN epsilon parameter
        self.dbscan_min_samples = rospy.get_param("~dbscan_min_samples", 10)  # DBSCAN min samples parameter
        
        # Cluster size parameters
        self.min_cluster_size = rospy.get_param("~min_cluster_size", 10)  # Minimum number of points in a cluster
        self.max_cluster_size = rospy.get_param("~max_cluster_size", 400)  # Maximum number of points in a cluster

    def point_cloud_callback(self, msg):
        # Convert PointCloud2 to numpy array
        points = self.convert_point_cloud_to_numpy(msg)
        if points.shape[0] < 3:
            rospy.logwarn("Not enough points for processing.")
            return

        # Apply crop filter
        cropped_points = self.apply_crop_filter(points)
        if cropped_points.shape[0] < 3:
            rospy.logwarn("Not enough points after cropping.")
            return

        # Remove ground plane
        non_ground_points = self.remove_ground_plane(cropped_points)
        if non_ground_points.shape[0] < 3:
            rospy.logwarn("Not enough points after ground removal.")
            return

        # Apply voxelization
        voxelized_points = self.apply_voxelization(non_ground_points)
        if voxelized_points.shape[0] < 3:
            rospy.logwarn("Not enough points after voxelization.")
            return

        # Publish the processed point cloud
        processed_cloud_msg = pc2.create_cloud_xyz32(msg.header, voxelized_points)
        self.processed_points_pub.publish(processed_cloud_msg)

        # Perform clustering
        labels = self.perform_clustering(voxelized_points)

        # Publish clustered points
        self.publish_clustered_points(voxelized_points, labels, msg.header)

        # Compute and publish centroids with cluster size filtering
        self.publish_centroids(voxelized_points, labels, msg.header)

    def convert_point_cloud_to_numpy(self, cloud_msg):
        # Convert PointCloud2 to numpy array
        points_list = []
        for point in pc2.read_points(cloud_msg, field_names=("x", "y", "z"), skip_nans=True):
            points_list.append([point[0], point[1], point[2]])
        return np.array(points_list)

    def apply_crop_filter(self, points):
        x_min, x_max = self.crop_x
        y_min, y_max = self.crop_y
        z_min, z_max = self.crop_z

        mask = (
            (points[:, 0] >= x_min) & (points[:, 0] <= x_max) &
            (points[:, 1] >= y_min) & (points[:, 1] <= y_max) &
            (points[:, 2] >= z_min) & (points[:, 2] <= z_max)
        )
        return points[mask]

    def remove_ground_plane(self, points):
        plane = Plane()
        equation, inliers = plane.fit(points, thresh=self.plane_thresh, maxIteration=self.plane_max_iter)

        if equation is not None and len(inliers) > 0:
            # Normalize the plane equation
            normal_vector = equation[:3]
            norm = np.linalg.norm(normal_vector)
            if norm == 0:
                return points
            unit_normal = normal_vector / norm

            # Check if the plane is ground based on the normal vector's z-component
            if abs(unit_normal[2]) > 0.9:  # Ground plane
                non_ground_points = np.delete(points, inliers, axis=0)
                rospy.loginfo("Ground plane detected and removed.")
                return non_ground_points
            else:
                rospy.loginfo("Detected plane is not ground.")
                return points
        else:
            rospy.loginfo("No plane found.")
            return points  # Return all points if no plane is detected

    def apply_voxelization(self, points):
        voxel_size = self.voxel_size
        voxel_indices = np.floor(points / voxel_size).astype(np.int32)
        coords, unique_indices = np.unique(voxel_indices, axis=0, return_index=True)
        return points[unique_indices]

    def perform_clustering(self, points):
        if points.shape[0] > 0:
            clustering = DBSCAN(eps=self.dbscan_eps, min_samples=self.dbscan_min_samples).fit(points)
            return clustering.labels_
        else:
            return np.array([])

    def publish_clustered_points(self, points, labels, header):
        unique_labels = set(labels)
        unique_labels.discard(-1)  # Remove noise label
        num_clusters = len(unique_labels)
        colors = self.get_colors(num_clusters)
        label_color_map = {label: color for label, color in zip(unique_labels, colors)}
        # For noise, set color to white
        label_color_map[-1] = (255, 255, 255)
        # Build point list with colors
        point_list = []
        for point, label in zip(points, labels):
            color = label_color_map.get(label, (255, 255, 255))
            r, g, b = color
            rgb = self.rgb_to_float(r, g, b)
            point_list.append([point[0], point[1], point[2], rgb])
        fields = [
            PointField('x', 0, PointField.FLOAT32, 1),
            PointField('y', 4, PointField.FLOAT32, 1),
            PointField('z', 8, PointField.FLOAT32, 1),
            PointField('rgb', 16, PointField.FLOAT32, 1),
        ]
        clustered_cloud_msg = pc2.create_cloud(header, fields, point_list)
        self.clustered_points_pub.publish(clustered_cloud_msg)

    def publish_centroids(self, points, labels, header):
        unique_labels = set(labels)
        unique_labels.discard(-1)  # Remove noise

        centroid_with_label_array = CentroidWithLabelArray()
        centroid_with_label_array.header = header

        marker_array = MarkerArray()
        text_marker_array = MarkerArray()  # 텍스트 마커를 저장할 배열 추가
        marker_id = 0

        for cluster_id in unique_labels:
            cluster_points = points[labels == cluster_id]
            cluster_size = cluster_points.shape[0]

            # Filter clusters based on size
            if cluster_size < self.min_cluster_size or cluster_size > self.max_cluster_size:
                rospy.loginfo(f"Cluster {cluster_id} ignored due to size {cluster_size}.")
                continue

            # Compute centroid
            centroid = np.mean(cluster_points, axis=0)

            # Create CentroidWithLabel message
            centroid_msg = CentroidWithLabel()
            centroid_msg.centroid = Point(*centroid)
            centroid_msg.label = "unknown"  # Initialize as unknown; will be classified in another node
            centroid_with_label_array.centroids.append(centroid_msg)

            # Determine color based on cluster size (예: 클러스터 크기가 클수록 빨간색, 작을수록 파란색)
            # 여기서는 단순히 클러스터 크기에 비례하여 색상을 변경
            # 클러스터 크기에 따라 색상 범위를 조정할 수 있습니다.
            max_size = self.max_cluster_size
            size_ratio = min(cluster_size / max_size, 1.0)  # 0~1 사이로 정규화
            r = size_ratio
            g = 0.0
            b = 1.0 - size_ratio
            color = (r, g, b, 1.0)  # RGBA

            # Create Marker for visualization
            marker = Marker()
            marker.header = header
            marker.ns = "centroids"
            marker.id = marker_id
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position = Point(*centroid)
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.3
            marker.scale.y = 0.3
            marker.scale.z = 0.3
            marker.color.r = color[0]
            marker.color.g = color[1]
            marker.color.b = color[2]
            marker.color.a = color[3]
            marker.lifetime = rospy.Duration(1)
            marker_array.markers.append(marker)

            # Create Text Marker for cluster size
            text_marker = Marker()
            text_marker.header = header
            text_marker.ns = "centroid_sizes"
            text_marker.id = marker_id  # 같은 ID를 사용
            text_marker.type = Marker.TEXT_VIEW_FACING
            text_marker.action = Marker.ADD
            text_marker.pose.position = Point(*centroid)
            text_marker.pose.position.z += 0.5  # 텍스트를 클러스터 위에 표시
            text_marker.pose.orientation.w = 1.0
            text_marker.scale.z = 0.5  # 텍스트 크기
            text_marker.color.r = 1.0
            text_marker.color.g = 1.0
            text_marker.color.b = 1.0
            text_marker.color.a = 1.0
            text_marker.text = str(cluster_size)  # 클러스터 크기 텍스트
            text_marker.lifetime = rospy.Duration(1)
            text_marker_array.markers.append(text_marker)

            marker_id += 1

        # Publish centroids
        if len(centroid_with_label_array.centroids) > 0:
            self.centroid_pub.publish(centroid_with_label_array)
            self.centroid_markers_pub.publish(marker_array)
            self.text_markers_pub.publish(text_marker_array)  # 텍스트 마커 퍼블리시
            rospy.loginfo(f"Published {len(centroid_with_label_array.centroids)} centroids.")
        else:
            rospy.loginfo("No centroids to publish after filtering.")

    def get_colors(self, num_colors):
        import random
        random.seed(0)  # For consistent colors
        colors = []
        for _ in range(num_colors):
            colors.append((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
        return colors

    def rgb_to_float(self, r, g, b):
        import struct
        rgb = (int(r) << 16) | (int(g) << 8) | int(b)
        s = struct.pack('>I', rgb)
        rgb_float = struct.unpack('>f', s)[0]
        return rgb_float

if __name__ == "__main__":
    try:
        processor = LidarProcessor()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
