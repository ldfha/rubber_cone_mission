#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from ultralytics import YOLO
import cv2
from vision_msgs.msg import Detection2D, Detection2DArray, ObjectHypothesisWithPose

# 클래스 레이블을 정의합니다.
CLASS_NAMES = ['coneBs', 'coneYs']  # 0: 'coneBs', 1: 'coneYs'

# 노드 초기화
rospy.init_node('yolo_camera4_node')
bridge = CvBridge()
model = YOLO("/home/unita/erp_final_ws/src/rubber_cone_mission/src/best.pt", 'cuda:0')

# 바운딩 박스 크기 축소 비율 설정 (예: 0.8 = 80%)
SHRINK_RATIO = 0.8

# Publisher 초기화 - 토픽 이름을 요청대로 변경
bbox_pub = rospy.Publisher('/yolo/coneYs_bounding_boxes', Detection2DArray, queue_size=10)

def image_callback(msg):
    # 카메라 이미지를 OpenCV 형식으로 변환
    frame = bridge.imgmsg_to_cv2(msg, 'bgr8')
    results = model(frame)

    # Detection2DArray 메시지 생성
    detection_array_msg = Detection2DArray()

    # 결과 처리
    if results[0].boxes is not None:
        for box in results[0].boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()  # 바운딩 박스 좌표 추출
            conf = box.conf[0].tolist()  # 신뢰도 추출
            cls = int(box.cls[0].tolist())  # 클래스 ID 추출

            # 'coneBs' 클래스 (ID: 0)인 경우 무시하고 넘어감
            if CLASS_NAMES[cls] == 'coneBs':
                continue  # 다음 탐지 결과로 넘어감

            # 'coneYs'만 처리 (ID: 1)
            if CLASS_NAMES[cls] == 'coneYs' and conf > 0.5:  # 신뢰도 0.1 이상일 때만 처리
                # 바운딩 박스 중심 계산
                center_x = (x1 + x2) / 2
                center_y = (y1 + y2) / 2

                # 기존 크기 계산
                width = x2 - x1
                height = y2 - y1

                # 바운딩 박스 크기 축소
                new_width = width * SHRINK_RATIO
                new_height = height * SHRINK_RATIO

                # 새로운 좌표 계산 (축소된 크기에 따라 좌표 조정)
                new_x1 = center_x - new_width / 2
                new_y1 = center_y - new_height / 2
                new_x2 = center_x + new_width / 2
                new_y2 = center_y + new_height / 2

                # Detection2D 메시지 생성
                detection_msg = Detection2D()

                # 바운딩 박스 위치 및 크기 설정 (축소된 크기 사용)
                detection_msg.bbox.center.x = center_x
                detection_msg.bbox.center.y = center_y
                detection_msg.bbox.size_x = new_width
                detection_msg.bbox.size_y = new_height

                # ObjectHypothesisWithPose 생성 및 추가
                hypothesis = ObjectHypothesisWithPose()
                hypothesis.score = conf
                hypothesis.id = cls

                # Detection2D에 Hypothesis 추가
                detection_msg.results.append(hypothesis)

                # Detection2DArray에 Detection2D 추가
                detection_array_msg.detections.append(detection_msg)

                # 축소된 바운딩 박스를 이미지에 그리기
                label = f"coneYs: {conf:.2f}"
                cv2.rectangle(frame, (int(new_x1), int(new_y1)), (int(new_x2), int(new_y2)), (0, 255, 0), 2)
                cv2.putText(frame, label, (int(new_x1), int(new_y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Detection2DArray 메시지 발행 (coneYs만 포함)
    bbox_pub.publish(detection_array_msg)

    # 이미지 표시 (디버깅 용도)
    cv2.imshow('YOLOv9 - coneYs Detection', frame)
    cv2.waitKey(1)

# 이미지 토픽 구독
image_sub = rospy.Subscriber('/camera4/usb_cam_4/image_raw', Image, image_callback)

# ROS 노드 실행
rospy.spin()
