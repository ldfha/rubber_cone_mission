#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import PoseStamped
from erp_driver.msg import erpCmdMsg, erpStatusMsg
from std_msgs.msg import Float32

class CommandPublisher:
    def __init__(self):
        rospy.init_node('command_publisher', anonymous=True)
        self.ctrl_cmd_msg = erpCmdMsg()

        # Waypoint 구독
        self.waypoint_sub = rospy.Subscriber('/waypoints', PoseStamped, self.waypoint_callback)

        # ERP42 제어 명령 퍼블리셔
        self.erp_cmd_pub = rospy.Publisher('/erp42_ctrl_cmd', erpCmdMsg, queue_size=1)

        # ERP42 상태 구독 (속도 및 조향각 정보)
        self.status_sub = rospy.Subscriber('/erp42_status', erpStatusMsg, self.status_callback)

        # 차량의 현재 상태
        self.current_position = [-1.0, 0.0]  # 차량의 초기 위치 (0, 0)
        self.current_speed = 0  # 현재 차량 속도
        self.current_steering_angle = 0  # 현재 조향각 (degree 단위)
        self.previous_steering_angle = 0  # 이전 주기에서의 조향각

    def status_callback(self, msg):
        # 차량의 현재 속도 및 조향각을 업데이트
        self.current_speed = msg.speed  # 현재 차량의 속도 (0~255 범위)
        self.current_steering_angle = (msg.steer / 2000.0) * 30  # ERP42의 조향각 범위(-2000 ~ 2000)에서 degree로 변환

    def waypoint_callback(self, msg):
        # Waypoint 정보 추출
        waypoint_x = msg.pose.position.x
        waypoint_y = msg.pose.position.y

        # Waypoint까지의 각도 계산 (라디안 값)
        angle_to_waypoint = math.atan2(waypoint_y - self.current_position[1], waypoint_x - self.current_position[0])

        # 각도를 degree 단위로 변환
        angle_to_waypoint_deg = math.degrees(angle_to_waypoint)

        # 최종 조향각 계산 (ERP42의 조향각 범위에 맞춰 변환, -30도 ~ 30도 사이로 제한)
        steering_angle_deg = max(min(angle_to_waypoint_deg, 30), -30)  # -30도 ~ 30도 사이로 제한

        # ERP42의 조향각 범위(-2000 ~ 2000)로 변환
        steering_angle_cmd = int((steering_angle_deg / 30.0) * 2000)

        # 조향각 변화율 계산 (degree/s)
        steering_rate = abs(self.current_steering_angle - self.previous_steering_angle) / rospy.get_param("~rate", 0.1)  # 기본 주기 0.1초

        # 각도에 따라 속도를 가변적으로 설정 (조향각이 클수록 속도를 낮춤)
        if abs(steering_angle_deg) < 5 and steering_rate < 10:
            speed = 60  # 직선 구간 및 조향 변화가 거의 없는 경우: 빠른 속도
        elif abs(steering_angle_deg) < 15 and steering_rate < 20:
            speed = 45  # 중간 각도 및 조향 변화가 적당한 경우: 중간 속도
        else:
            speed = 30  # 큰 각도 또는 급격한 조향 변화가 있을 때: 낮은 속도

        # ERP42 제어 명령 메시지 생성
        self.ctrl_cmd_msg.steer = -steering_angle_cmd  # 조향 명령 설정
        self.ctrl_cmd_msg.speed = speed #speed  # 각도에 따라 동적으로 설정된 속도 값 사용
        self.ctrl_cmd_msg.gear = 0  # 기어 설정 (0: 중립)
        self.ctrl_cmd_msg.e_stop = False  # 비상 정지 설정 (False: 비상 정지 해제)
        self.ctrl_cmd_msg.brake = 0  # 브레이크 해제

        # 제어 명령 퍼블리시
        self.erp_cmd_pub.publish(self.ctrl_cmd_msg)
        rospy.loginfo(f"Published command: speed={speed}, steer={-steering_angle_cmd}, rate={steering_rate}")

        # 이전 조향각 업데이트
        self.previous_steering_angle = self.current_steering_angle

if __name__ == '__main__':
    try:
        command_publisher = CommandPublisher()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
