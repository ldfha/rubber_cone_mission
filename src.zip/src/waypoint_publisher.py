#!/usr/bin/env python3

import rospy
import math
from geometry_msgs.msg import PoseStamped, Point
from erp_driver.msg import erpStatusMsg  # 조향각 정보 구독을 위한 메시지 타입
from rubber_cone_mission.msg import CentroidWithLabelArray
from visualization_msgs.msg import Marker, MarkerArray

class WaypointExtractor:
    def __init__(self):
        rospy.init_node('waypoint_extractor', anonymous=True)

        # 센트로이드 정보를 구독
        self.centroid_sub = rospy.Subscriber('/classified_centroids', CentroidWithLabelArray, self.centroid_callback)
        
        # 조향각 정보 구독
        self.steering_angle_sub = rospy.Subscriber('/erp42_status', erpStatusMsg, self.steering_angle_callback)

        # Waypoint 퍼블리셔 (PoseStamped 및 MarkerArray용)
        self.waypoint_pub = rospy.Publisher('/waypoints', PoseStamped, queue_size=10)
        self.waypoint_marker_pub = rospy.Publisher('/waypoint_markers', MarkerArray, queue_size=10)

        # 파라미터 설정
        self.centroid_threshold = 5.0  # 임계값 (거리가 너무 먼 Centroid 무시)
        self.default_offset = 2.0  # 한쪽 센트로이드만 감지될 때 사용하는 오프셋
        self.steering_angle_deg = 0.0  # 조향각 (기본값 0)
        self.max_steering_angle_deg = 30.0  # 최대 조향각 (30도 기준)

    def steering_angle_callback(self, msg):
        # ERP42의 조향각 범위 (-2000 ~ 2000)를 -30도 ~ 30도로 변환
        self.steering_angle_deg = (msg.steer / 2000.0) * 30.0
        #rospy.loginfo(f"Current steering angle: {self.steering_angle_deg:.2f} degrees")

    def centroid_callback(self, msg):
        # CentroidWithLabelArray에서 센트로이드들을 레이블에 따라 분류
        left_centroids = []
        right_centroids = []

        for centroid_with_label in msg.centroids:
            point = centroid_with_label.centroid
            label = centroid_with_label.label

            # 차량과 센트로이드 간의 거리 계산
            distance = math.sqrt(point.x**2 + point.y**2)
            # 임계값 필터링 (Centroid가 너무 먼 경우 무시)
            if distance > self.centroid_threshold:
                continue

            if label == 'left':
                left_centroids.append(point)
            elif label == 'right':
                right_centroids.append(point)

        # 센트로이드들을 x 좌표 기준으로 정렬 (전방 기준)
        left_centroids.sort(key=lambda p: p.x)
        right_centroids.sort(key=lambda p: p.x)

        # 웨이포인트 계산 (양쪽 센트로이드가 존재할 때)
        if left_centroids and right_centroids:
            self.calculate_waypoints(left_centroids, right_centroids)
        # 왼쪽 센트로이드만 존재할 때
        elif left_centroids:
            rospy.logwarn("Only left centroids detected")
            self.calculate_single_side_waypoint(left_centroids, "left")
        # 오른쪽 센트로이드만 존재할 때
        elif right_centroids:
            rospy.logwarn("Only right centroids detected")
            self.calculate_single_side_waypoint(right_centroids, "right")
        else:
            rospy.logwarn("No centroids detected.")

    def calculate_waypoints(self, left_centroids, right_centroids):
        waypoints = []
        min_length = min(len(left_centroids), len(right_centroids))

        for i in range(min_length):
            left_point = left_centroids[i]
            right_point = right_centroids[i]

            # 중점 계산
            mid_x = (left_point.x + right_point.x) / 2
            mid_y = (left_point.y + right_point.y) / 2
            waypoints.append(Point(mid_x, mid_y, 0.0))

        self.publish_waypoint_markers(waypoints)
        self.publish_waypoints(waypoints)

    def calculate_single_side_waypoint(self, centroids, side):
        waypoints = []
        for i in range(1, len(centroids)):
            prev_point = centroids[i - 1]
            curr_point = centroids[i]

            if side == "left":
                waypoint_x = curr_point.x
                waypoint_y = curr_point.y - self.default_offset 
            elif side == "right":
                waypoint_x = curr_point.x
                waypoint_y = curr_point.y + self.default_offset

            waypoints.append(Point(waypoint_x, waypoint_y, 0.0))

        self.publish_waypoint_markers(waypoints)
        self.publish_waypoints(waypoints)

    def publish_waypoints(self, waypoints):
        if waypoints:
            last_waypoint = waypoints[-1]
            waypoint_msg = PoseStamped()
            waypoint_msg.header.stamp = rospy.Time.now()
            waypoint_msg.header.frame_id = "velodyne"
            waypoint_msg.pose.position = last_waypoint
            waypoint_msg.pose.orientation.w = 1.0

            self.waypoint_pub.publish(waypoint_msg)
            rospy.loginfo(f"waypoint: ({last_waypoint.x}, {last_waypoint.y})")

    def publish_waypoint_markers(self, waypoints):
        marker_array = MarkerArray()

        for idx, waypoint in enumerate(waypoints):
            marker = Marker()
            marker.header.frame_id = "velodyne"
            marker.header.stamp = rospy.Time.now()
            marker.ns = "waypoints"
            marker.id = idx
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            marker.pose.position = waypoint
            marker.pose.orientation.w = 1.0
            marker.scale.x = 0.2
            marker.scale.y = 0.2
            marker.scale.z = 0.2
            marker.color.r = 1.0
            marker.color.g = 1.0
            marker.color.b = 1.0
            marker.color.a = 1.0

            marker.lifetime = rospy.Duration(0.3)

            marker_array.markers.append(marker)

        self.waypoint_marker_pub.publish(marker_array)

if __name__ == '__main__':
    extractor = WaypointExtractor()
    rospy.spin()
